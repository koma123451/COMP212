﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Data;
using System.Collections;

namespace CovidData
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private DataTable dataTable = new DataTable();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //DataTable dataTable = dataGridView1.
            DataRowView row = (DataRowView)dataGridView1.SelectedItem;
            //dataGridView1.ItemsSource.Remove(dataGridView1.SelectedIndex);
            dataTable.Rows.Remove(row.Row);

            DataView dv = new DataView(dataTable);
            this.dataGridView1.ItemsSource = dv;
        }

        private DataView createDataSource()
        {
            DataRow dr;

            dataTable.Columns.Add("ProvinceState");
            dataTable.Columns.Add("CountryRegion");
            dataTable.Columns.Add("Number of Deaths");
            // dataTable.Columns.Add("Record Date");

            int i = 0;

            foreach (string line in File.ReadLines("c:\\tmp\\covid19_deaths_global.csv"))
            {
                dr = dataTable.NewRow();
                dr[0] = line.Split(',').ElementAt(0);
                dr[1] = line.Split(',').ElementAt(1);
                dr[2] = line.Split(',').ElementAt(2);

                if (i >= 1)
                {
                    dataTable.Rows.Add(dr);
                }

                i++;
            }

            DataView dv = new DataView(dataTable);
            return dv;
        }

        private void Display_Click(object sender, RoutedEventArgs e)
        {
            /*
            string delimiter = ",";
            string filename = ("c:\\tmp\\covid19_deaths_global.csv");
            DataSet dataset = new DataSet();
            StreamReader sr = new StreamReader(filename);
            string allData = sr.ReadToEnd();
            string[] rows = allData.Split("\r".ToCharArray());
            foreach (string r in rows)
            {
                string[] items = r.Split(delimiter.ToCharArray());
               // dataset.Tables[tablename].Rows.Add(items);
            }
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("Country/Region");
            dataTable.Columns.Add("Province/State");
            dataTable.Columns.Add("Number of Deaths");
            dataTable.Columns.Add("Record Date");
            //this.dataGridView1.DataSource = dataset.Tables[0].DefaultView;
            //this.dataGridView1.DataContext = dataset.Tables[0].DefaultView;
            //rows.ForEach(x => { dataTable.Rows.Add(x); });

            this.dataGridView1.DataContext = dataTable;
            string[] str = File.ReadAllLines("c:\\tmp\\covid19_deaths_global.csv");

            DataTable dt = new DataTable();

            string[] temp = str[0].Split(',');

            for (int i = 0; i < 3; i++)
            {
                dt.Columns.Add(temp[i]);
            }

            for (int i = 1; i < str.Length; i++)
            {
                string[] s = str[i].Split(',');
                Index start = 1;
                Index end = 4;
                dt.Rows.Add(s[start..end]);
            }

            this.dataGridView1.DataContext = dt;
             this.dataGridView1.bi
            */

            this.dataGridView1.ItemsSource = createDataSource();
        }

        private void DataGrid_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
           
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
