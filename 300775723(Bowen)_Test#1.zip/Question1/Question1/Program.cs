﻿using System;
using System.Collections.Generic;

namespace Question1
{
    class Program
    {
        Dictionary<string, Student> studentDictionary = new Dictionary<string, Student>();

        public void add(Student s)
        {
            if (!studentDictionary.ContainsKey(s.Id))
            {
                studentDictionary.Add(s.Id, s);
                Console.WriteLine("Ne6w student added to the dictionary");
            }
        }


        public void remove (string id)
        {

            if (!studentDictionary.ContainsKey(id))
            {
                studentDictionary.Remove(id);
                Console.WriteLine("Student removed to the dictionary");
            }
        }


        public bool search(Student s)
        {
            bool found = false;
            foreach (KeyValuePair<string, Student> kvp in studentDictionary)
            {
                if (kvp.Key == s.Id)
                {
                    found = true;
                }
            }
            return found; 
        }


        static void Main(string[] args)
        {
            Program program = new Program();
            Console.WriteLine("Enter new student info");
            string name = Console.ReadLine();
            string phone = Console.ReadLine();
            string id = Console.ReadLine();
            Student s = new Student(name, phone, id);
            program.add(s);


            Console.WriteLine("Enter new student info");
             name = Console.ReadLine();
             phone = Console.ReadLine();
             id = Console.ReadLine();
             s = new Student(name, phone, id);
            program.add(s);

            Console.WriteLine("Student in the dictionary are:");
            foreach (KeyValuePair<string, Student> kv in program.studentDictionary)
            {
                Console.WriteLine(kv.Value.Name);
            }

            Console.WriteLine("Enter student Id to remove");
            id = Console.ReadLine();
            program.remove(id);


            Console.WriteLine("Student in the dictionary are:");
            foreach (KeyValuePair<string, Student> kv in program.studentDictionary)
            {
                Console.WriteLine(kv.Value.Name);
            }


            //DisplayDictionary(studentDictionary);


        }
    }
}
