﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Question1
{
    class Student
    {
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        public string Id { get; set; }

        public Student(string n, string p, string i)
        {
            Name = n;
            PhoneNumber = p;
            Id = i;
        }
    }
}
