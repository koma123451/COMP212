﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Question2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public List<String> userList = new List<string>();

        private static void AddUserList(string user, List<String> list)
        {
            if (list!= null  && !list.Contains(user))
            {
                list.Add(user);

                MessageBox.Show("User added to the list");

            }
            else
            {
                MessageBox.Show("User is already exist");
            }
        }

        public void RemoveUserList(string user, List<String> list)
        {
            if (list.Contains(user))
            {
                list.Remove(user);
                MessageBox.Show("User removed from the list");
            }
            else
            {
                MessageBox.Show("User does not exist");
            }
        }//1

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string user = textBox1.Text;
            AddUserList(user, userList);
            listBox1.DataSource = null;
            listBox1.DataSource = userList;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string user = textBox1.Text;
            RemoveUserList(user, userList);
            listBox1.DataSource = null;
            listBox1.DataSource = userList;
        }

        private async  void button4_Click(object sender, EventArgs e)
        {
            
            if (userList.Count == 0)
            {
                MessageBox.Show("User list is empty");
                return;
            }

            string timeStr = textBox2.Text;
            int time = Int32.Parse(timeStr);
            time = time * 1000;
            await Task.Run(() =>
            {
                Thread.Sleep(time);
            });


            publish pbt = new publish();
            foreach (string user in userList)
            {
                Console.WriteLine("Sending message to all the users"); 
            }

            pbt.PublishInfo(textBox3.Text);

            MessageBox.Show("Message sent to all users");

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
